import numpy as np
import pickle
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers

# ========== Global Param ==========

SIZE = 70
LONGEST_MOLECULE = 325
BATCH_SIZE = 64

METRICS = [
    keras.metrics.TruePositives(name='tp'),
    keras.metrics.FalseNegatives(name='fn'),
    keras.metrics.TrueNegatives(name='tn'), 
    keras.metrics.FalsePositives(name='fp'),
    keras.metrics.AUC(name='auc'),
]

# ========== Data set ==========

with open('../SR-ARE-score/names_onehots.pickle', 'rb') as score_pickle_file:
    score_onehots_r = pickle.load(score_pickle_file)['onehots']
    score_onehots = score_onehots_r[:, :, :, np.newaxis]

# ========== Weight balance ==========

# ========== Callback ==========

# ========== Graphing ==========

# ========== Model ==========

def my_model(output_bias = None, k_reg = None):
    if output_bias is not None:
        output_bias = tf.keras.initializers.Constant(output_bias)
    inputs = keras.Input(shape=(SIZE, LONGEST_MOLECULE, 1))
    x = layers.Conv2D(8, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(inputs)
    x = layers.Conv2D(8, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(16, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(16, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(32, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(32, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(64, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(64, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(128, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
#    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Flatten()(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(1, activation='sigmoid', bias_initializer=output_bias)(x)
    
    model = keras.Model(inputs=inputs, outputs=outputs)
    model.load_weights('trained_weights/')
    model.compile(
        loss = keras.losses.BinaryCrossentropy(),
        optimizer = keras.optimizers.Adam(lr=0.001),
        metrics = METRICS)

    return model

model = my_model(k_reg = regularizers.l2(0.01))
score_label = model.predict(score_onehots)
np.savetxt('labels.txt', score_label, fmt='%.0f')
