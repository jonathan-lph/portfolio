import numpy as np
import pickle
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, regularizers
from tensorflow.keras.callbacks import TensorBoard

# ========== Global Param ==========

SIZE = 70
LONGEST_MOLECULE = 325
BATCH_SIZE = 64

METRICS = [
    keras.metrics.TruePositives(name='tp'),
    keras.metrics.FalseNegatives(name='fn'),
    keras.metrics.TrueNegatives(name='tn'), 
    keras.metrics.FalsePositives(name='fp'),
    keras.metrics.AUC(name='auc'),
]

# ========== Data set ==========

with open('/content/drive/My Drive/data/SR-ARE-train/names_onehots.pickle', 'rb') as train_pickle_file:
    train_onehots_r = pickle.load(train_pickle_file)['onehots']
    train_onehots = train_onehots_r[:, :, :, np.newaxis]

with open('/content/drive/My Drive/data/SR-ARE-test/names_onehots.pickle', 'rb') as test_pickle_file:
    test_onehots_r = pickle.load(test_pickle_file)['onehots']
    test_onehots = test_onehots_r[:, :, :, np.newaxis]

train_label = np.loadtxt(
    '/content/drive/My Drive/data/SR-ARE-train/names_labels.txt', 
    dtype = 'int32', delimiter = ',', usecols = 1)

test_label  = np.loadtxt(
    '/content/drive/My Drive/data/SR-ARE-test/names_labels.txt',
    dtype = 'int32', delimiter = ',', usecols = 1)

# ========== Weight balance ==========

non_toxic, toxic = np.bincount(train_label)
data_size = non_toxic + toxic
weight_0 = 1.0 / non_toxic * (data_size)/2
weight_1 = 1.0 / toxic * (data_size)/2
initial_bias = np.log([toxic/non_toxic])

# ========== Callback ==========

class Score(keras.callbacks.Callback):
    def on_epoch_end(self, epoch, logs=None):
        tp = logs['tp']
        fn = logs['fn']
        tn = logs['tn']
        fp = logs['fp']
        tpr = tp/(tp+fn)
        tnr = tn/(tn+fp)
        print('Epoch {}:'.format(epoch))
        print('>> TPR: {:4.0f} ({:4.0f}) = {:7.5f} - TNR: {:4.0f} ({:4.0f}) = {:7.5f}'.format(
            tp, fn, tpr, tn, fp, tnr))
        print('>> Loss: {:7.5f} - AUC: {:7.5f} - Score: {:7.5f}'.format(
            logs['loss'], logs['auc'], (tpr+tnr)/2))

early_stopping = tf.keras.callbacks.EarlyStopping(
    monitor='val_auc', 
    verbose=2, patience=10, mode='max',
    restore_best_weights=True)

# ========== Graphing ==========

import matplotlib as mpl
import matplotlib.pyplot as plt
mpl.rcParams['figure.figsize'] = (12, 10)
colors = plt.rcParams['axes.prop_cycle'].by_key()['color']

def plot_metrics(history):
    metrics =  ['loss', 'auc']
    for n, metric in enumerate(metrics):
        name = metric.replace("_"," ").capitalize()
        plt.subplot(2,2,n+1)
        plt.plot(history.epoch,  history.history[metric], color=colors[0], label='Train')
        plt.plot(history.epoch, history.history['val_'+metric],
             color=colors[0], linestyle="--", label='Val')
        plt.xlabel('Epoch')
        plt.ylabel(name)
    if metric == 'loss':
        plt.ylim([0, plt.ylim()[1]])
    elif metric == 'auc':
        plt.ylim([0,1])
    else:
        plt.ylim([0,1])

    plt.legend()

# ========== Model ==========

def my_model(output_bias = None, k_reg = None):
    if output_bias is not None:
        output_bias = tf.keras.initializers.Constant(output_bias)
    inputs = keras.Input(shape=(SIZE, LONGEST_MOLECULE, 1))
    x = layers.Conv2D(8, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(inputs)
    x = layers.Conv2D(8, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(16, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(16, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(32, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(32, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(64, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.Conv2D(64, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Conv2D(128, 3, strides=(1,1), padding='same', kernel_regularizer=k_reg)(x)
#    x = layers.BatchNormalization()(x)
    x = keras.activations.relu(x)
    x = layers.MaxPooling2D()(x)
    x = layers.Flatten()(x)
    x = layers.Dense(256, activation='relu')(x)
    x = layers.Dropout(0.5)(x)
    outputs = layers.Dense(1, activation='sigmoid', bias_initializer=output_bias)(x)
    
    model = keras.Model(inputs=inputs, outputs=outputs)
    model.compile(
        loss = keras.losses.BinaryCrossentropy(),
        optimizer = keras.optimizers.Adam(lr=0.001),
        metrics = METRICS)

    return model

def run_model():
    model = my_model(k_reg = regularizers.l2(0.01))
    history = model.fit(train_onehots, train_label, 
        batch_size=BATCH_SIZE, epochs=120, verbose=0, 
        class_weight = {0: weight_0, 1: weight_1},
        callbacks=[Score(), early_stopping])
    model.evaluate(test_onehots, test_label, 
        batch_size=BATCH_SIZE, verbose=2,
        callbacks=[Score()])
    model.save('data/trained_model/')
    plot_metrics(history)

def first_run():
    model = my_model(output_bias = initial_bias)
    model.evaluate(test_onehots, test_label, 
        batch_size=BATCH_SIZE, verbose=2,
        callbacks=[Score()])
    model.save_weights('data/initial_weights/')

def print_model():
    model = my_model()
    model.summary()

#print_model()
#first_run()
run_model()
